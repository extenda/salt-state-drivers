///////////////////////////////////////////////////////////////////

 - starbsc10javapos Ver1.13.3 linux -
       Readme File                                       06/17/2013
       
   Copyright (C) 2013 Star Micronics Co., Ltd. All rights reserved.
///////////////////////////////////////////////////////////////////

*This ReadMe File applies to starbsc10javapos Ver1.13.3 for linux

  Thank you very much for purchasing Star Printer.

  Contents:

    1.  Package Contents
    2.  Supported Model
    3.  Supported Operating Systems
    4.  Supported InterFace
    5.  Java Virtual Machine Requirement
    6.  Preparation - Installing IOPortConnection
    7.  Configuration Sample - jpos.xml
    8.  Usage - Test Application
    9.  ASB Setting(USB Printer Class , Serial, Parallel)
    10. Restrictions
    11. Release Notes


===================
1. Package Contents
===================
    . starjavapos.jar
    . ioconnection.jar
    . jpos113-controls.jar
    . jcl.jar
    . xercesimpl.jar
    . xml-apis.jar
    . jpos.xml
    . StarReceiptTest.java
    . StarCashDrawerTest.java
    . Star.gif
    . IOPortConnection_Install_x32(x64)
    . SoftwareLicenseAgreement.pdf
    . SoftwareLicenseAgreementAppendix.pdf
    . readme.txt
    . 49-starusbprn.rules


==================
2. Supported Model
==================
    BSC10


==============================
3. Supported Operating Systems
==============================
    The evaluation environment is as follows:
        Red Hat Enterprise Linux 6.3
        openSUSE 12.1
        Fedora 13
        ubuntu 12.04 LTS
        ubuntu 10.10
        CentOS 6.3


======================
4. Supported InterFace
======================
    Serial
    Parallel
    Ethernet
    USB PrinterClass


===================================
5. Java Virtual Machine Requirement
===================================
    Java2 Standard Edition 1.4.2 or higher

    NOTE: We recommend using Java2 Standard Edition 5.0 or higher


============================================
6. Preparation - Installing IOPortConnection
============================================
    Browse to the StarJavaPOS directory "IOPortConnection_Install_x32(x64)" and run the bash script named
    "install.sh". To run it, login as root and issue this command in the terminal "/bin/bash install.sh" 
    once you change to this  directory. This will copy the library file to the "/usr/lib" directory and
    header file to the "/usr/include" directory.
    
    e.g) Ubuntu x32(x64)
    [star@localhost starbsc10javapos_1.13.2_linux_32/64bit]$ cd IOPortConnection_Install_x32(x64)/
    [star@localhost IOPortConnection_Install_x32(x64)]$ sudo /bin/bash install.sh
    Complete!


==================================
7. Configuration Sample - jpos.xml
==================================
    StarJavaPOS uses the JCL - Java Configuration Loader system for
    configuring the provided services.  The file jpos.xml contained
    in this package has been initialized with device entries for
    Star's newest printer products.

    The following is a list of the POSPrinter device entries
    contained in this file as indexed by their logicalName field:
        . POSPrinter_linux_serial
        . POSPrinter_linux_usb_printer_class
        . POSPrinter_linux_parallel
        . POSPrinter_linux_ethernet

    The following is a list of the CashDrawer device entries
    contained in this file as indexed by their logicalName field:
        . CashDrawer_linux_serial
        . CashDrawer_linux_usb_printer_class
        . CashDrawer_linux_parallel
        . CashDrawer_linux_ethernet


===========================
8. Usage - Test Application
===========================
    Open StarReceiptTest.java, StarCashDrawerTest.java.
    Then, refer to the usage instructions.


=====================================================
9. ASB Setting(USB Printer Class , Serial, Parallel)
=====================================================
    Confirm that the "ASB function" is "Valid" by self-printing.
    If "ASB function" is "Invalid", set to "Valid" by using FEED button in the self-printing mode.
    (If ASB function is not set "Valid", can not get the printer status.)


================
10. Restrictions
================
    - Module width of Code128 barcode is fixed to 0.141mm.

    - Please do use the JPOS_CH_INTERNAL in CheckHealth method..

    - In case need to rotate bitmap data using setbitmap method, set RotatePrint method before
      SetBitmap method and SetLogo method.

    - When the printer receives bitmap data from 513 to 566 dot width, it prints 512 dot width
      bitmap data and delete data exceeding 512 dot width without error message.
      Please set bitmap data less than 512 dot width.

    - If you are using a USB printer class in a Linux environment, there are two ways to specify port.
      There is a limitation by the F / W version.
      Please refer to the table below for details.

        +---------------+-------------------------------------+-------------------------------------------+
        |BSC10 Firmware |Specifying Model name to port name   | Specifying USB serial number to port name |
        |               |                                     |��cannot use muiltiple printers connection |
        +---------------+-------------------------------------+-------------------------------------------+
        |Version 1.1    |Cannot Use                           |Cannot Use                                 |
        +---------------+-------------------------------------+-------------------------------------------+
        |Version 1.2    |Cannot Use                           |Cannot Use                                 |
        +---------------+-------------------------------------+-------------------------------------------+
        |Version 1.3    |OK                                   |OK                                         |
        +---------------+-------------------------------------+-------------------------------------------+
        |Version 1.5    |OK                                   |Cannot Use                                 |
        +---------------+-------------------------------------+-------------------------------------------+
        |Version 1.6    |OK                                   |OK                                         |
        +---------------+-------------------------------------+-------------------------------------------+

        ��Follow the process below to confirm the firmware version of the printer.

          1. Load the paper roll and close the paper cover. 

          2. Hold down the FEED button and turn the POWER switch On.
             (Keep pressing the FEED button until self-printing starts.)
             Self-printing will starts and the current printer status will be printed out.
             When self-printing is complete, the POWER LED and ERROR LED flashes alternately
             and the printer waits for the FEED button to be pressed.
             Press the FEED button and release it within one second.
           
          3. Confirm the firmware version by looking near the top of the self test.


===================
11. Release History
===================
    06/17/2013 first release
        Ver 1.13.3 StarBSC10: staravapos_1.13.3_linux_32bit.zip
                              staravapos_1.13.3_linux_64bit.zip